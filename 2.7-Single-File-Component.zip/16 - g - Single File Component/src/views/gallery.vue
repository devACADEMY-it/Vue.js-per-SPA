<template>
  <p>gallery</p>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped></style>
