<template>
  <div>
    <h1 class="title">Hello World</h1>
    <p class="subtitle">
      My first website with
      <strong>Bulma</strong>!
    </p>
  </div>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped></style>
