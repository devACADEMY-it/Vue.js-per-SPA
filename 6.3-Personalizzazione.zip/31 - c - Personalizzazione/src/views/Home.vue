<template>
  <div>
    <h1 class="title">Hello World</h1>
    <p class="subtitle">
      My first website with
      <strong>Bulma</strong>!
    </p>
    <BButton>prova</BButton>
  </div>
</template>

<script>
export default {
  created() {
    this.$buefy.dialog.confirm({
      message: "Continue on this task?",
      onConfirm: () => this.$buefy.toast.open("User confirmed")
    })
  }
}
</script>

<style lang="scss" scoped>
@import "~bulma/sass/utilities/_all";

$button-background-color: #00f;

@import "~bulma/sass/elements/button";
</style>
