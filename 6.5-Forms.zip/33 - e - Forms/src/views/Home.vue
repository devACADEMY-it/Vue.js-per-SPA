<template>
  <div>
    <h1 class="title">Hello World</h1>
    <p class="subtitle">
      My first website with
      <strong>Bulma</strong>!
    </p>

    <form>
      <BField label="Email">
        <BInput type="email" v-model="email" maxlength="30"></BInput>
      </BField>

      <BField label="Password">
        <BInput
          type="password"
          v-model="password"
          password-reveal
          required
        ></BInput>
      </BField>

      <BField>
        <BButton type="is-primary" native-type="submit">Login</BButton>
      </BField>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoading: false,
      email: "",
      password: "",
      hasError: false
    }
  },
  methods: {
    checkEmail() {
      this.hasError = !this.email.includes("@")
    }
  }
}
</script>

<style lang="scss" scoped>
@import "~bulma/sass/utilities/_all";

$button-background-color: #00f;

@import "~bulma/sass/elements/button";
</style>
