<template>
  <div>
    <h1 class="title">Vue Time Tracking</h1>

    <FormCreateEntry @submit="submit" />

    <hr />

    <div v-if="entries.length === 0" class="notification">
      {{ $t("empty") }}
    </div>
    <Entry
      v-else
      v-for="entry of entries"
      :key="entry.id"
      :id="entry.id"
      :date="entry.date"
      :comment="entry.comment"
      :hours="entry.hours"
      @click="$router.push(`/details/${entry.id}`)"
      @remove="remove(entry.id)"
    />
  </div>
</template>

<script>
import FormCreateEntry from "@/components/FormCreateEntry"
import Entry from "@/components/Entry"

export default {
  components: {
    FormCreateEntry,
    Entry
  },
  computed: {
    entries() {
      return this.$store.state.entries
    }
  },
  methods: {
    async submit(payload) {
      await this.$store.dispatch("create", {
        date: payload.date,
        hours: payload.hours,
        comment: payload.comment
      })
    },
    async remove(payload) {
      await this.$store.dispatch("remove", payload)
    }
  },
  created() {
    this.$store.dispatch("find")
  },
  beforeRouteEnter(to, from, next) {
    console.log("beforeRouteEnter", to, from)
    next()
  },
  beforeRouteUpdate(to, from, next) {
    console.log("beforeRouteUpdate", to, from)
    next()
  },
  beforeRouteLeave(to, from, next) {
    console.log("beforeRouteLeave", to, from)
    next()
  }
}
</script>

<style lang="scss" scoped></style>
