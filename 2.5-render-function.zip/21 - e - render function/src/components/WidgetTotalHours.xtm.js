export default {
  name: "WidgetTotalHoursXTM",
  template: "#xtm",
  computed: {
    hours() {
      return this.$store.getters.totalHours
    }
  }
}
