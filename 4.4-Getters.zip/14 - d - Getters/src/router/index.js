import Vue from "vue"
import VueRouter from "vue-router"

Vue.use(VueRouter)

const routes = [
  {
    name: "index",
    path: "/",
    component: () => import(/* webpackChunkName: "index" */ "@/views/index")
  },
  {
    name: "details",
    path: "/details/:id",
    component: () => import(/* webpackChunkName: "details" */ "@/views/details")
  },
  {
    name: "gallery",
    path: "/gallery",
    component: () => import(/* webpackChunkName: "gallery" */ "@/views/gallery")
  },
  {
    path: "*",
    component: () => import(/* webpackChunkName: "404" */ "@/views/404")
  }
]

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
  console.log("beforeEach", to, from)

  next()
})

router.afterEach((to, from) => {
  console.log("afterEach", to, from)
})

export default router
