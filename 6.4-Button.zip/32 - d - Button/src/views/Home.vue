<template>
  <div>
    <h1 class="title">Hello World</h1>
    <p class="subtitle">
      My first website with
      <strong>Bulma</strong>!
    </p>

    <BButton
      @click="click"
      :loading="isLoading"
      rounded
      outlined
      type="is-primary"
      icon-left="account-card-details"
      tag="router-link"
      to="/about"
      >Prova</BButton
    >
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoading: false
    }
  },
  methods: {
    async click() {
      this.isLoading = true

      // eslint-disable-next-line no-unused-vars
      await new Promise((resolve, reject) => {
        setTimeout(() => {
          resolve()
        }, 3000)
      })

      this.isLoading = false
    }
  }
}
</script>

<style lang="scss" scoped>
@import "~bulma/sass/utilities/_all";

$button-background-color: #00f;

@import "~bulma/sass/elements/button";
</style>
