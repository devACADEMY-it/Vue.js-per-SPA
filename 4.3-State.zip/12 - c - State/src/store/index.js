import Vue from "vue"
import Vuex from "vuex"

Vue.use(Vuex)

export default new Vuex.Store({
  strict: process.env.NODE_ENV !== "production",

  state: {
    entries: []
  },
  mutations: {
    SET_ENTRIES(state, payload) {
      state.entries = payload
    },
    PUSH_ENTRY(state, payload) {
      state.entries.push(payload)
    },
    UPDATE_ENTRY(state, payload) {
      const target = state.entries.findIndex((e) => e.id === payload.id)

      state.entries.splice(target, 1, payload)
    },
    REMOVE_ENTRY(state, payload) {
      state.entries = state.entries.filter((e) => e.id !== payload)
    }
  },
  actions: {},

  modules: {}
})
