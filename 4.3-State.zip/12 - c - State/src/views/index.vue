<template>
  <div>
    <Entry
      v-for="entry of entries"
      :key="entry.id"
      :id="entry.id"
      :date="entry.date"
      :comment="entry.comment"
      :hours="entry.hours"
      @click="$router.push(`/details/${entry.id}`)"
      @remove="remove(entry.id)"
    />
  </div>
</template>

<script>
import Entry from "@/components/Entry"

export default {
  components: {
    Entry
  },
  computed: {
    entries() {
      return this.$store.state.entries
    }
  },
  methods: {
    remove() {}
  },
  beforeRouteEnter(to, from, next) {
    console.log("beforeRouteEnter", to, from)

    next()
  },
  beforeRouteUpdate(to, from, next) {
    console.log("beforeRouteUpdate", to, from)

    next()
  },
  beforeRouteLeave(to, from, next) {
    console.log("beforeRouteLeave", to, from)

    next()
  }
}
</script>

<style lang="scss" scoped></style>
