<template>
  <div id="app">
    <Navbar />

    <section class="section">
      <div class="container">
        <div class="columns">
          <div class="column is-3 sidebar"></div>
          <div class="column is-9 main">
            <router-view />
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import Navbar from "@/components/Navbar"

export default {
  name: "App",

  components: {
    Navbar
  }
}
</script>

<style lang="scss"></style>
