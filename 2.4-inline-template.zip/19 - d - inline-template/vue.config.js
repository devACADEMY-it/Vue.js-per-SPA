module.exports = {
  configureWebpack: {
    devtool: "source-map"
  },

  runtimeCompiler: true
}
