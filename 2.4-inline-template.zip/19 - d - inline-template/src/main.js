import Vue from "vue"
import App from "./App.vue"
import router from "./router"
import store from "./store"
import Buefy from "buefy"

import WidgetTotalHoursSTR from "@/components/WidgetTotalHours.str"
import WidgetTotalHoursXTM from "@/components/WidgetTotalHours.xtm"
import WidgetTotalHoursITM from "@/components/WidgetTotalHours.itm"

import "./assets/scss/app.scss"

Vue.use(Buefy)

Vue.config.productionTip = false

Vue.component("WidgetTotalHoursSTR", WidgetTotalHoursSTR)
Vue.component("WidgetTotalHoursXTM", WidgetTotalHoursXTM)
Vue.component("WidgetTotalHoursITM", WidgetTotalHoursITM)

new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount("#app")
