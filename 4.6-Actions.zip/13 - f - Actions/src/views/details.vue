<template>
  <FormCreateEntry :init="init" @submit="submit" />
</template>

<script>
import FormCreateEntry from "@/components/FormCreateEntry"

export default {
  components: {
    FormCreateEntry
  },
  data() {
    return {
      id: this.$route.params.id,
      init: {}
    }
  },
  methods: {
    async submit(payload) {
      await this.$store.dispatch("update", {
        id: this.id,
        date: payload.date,
        hours: payload.hours,
        comment: payload.comment
      })

      this.$router.replace("/")
    }
  }
}
</script>

<style lang="scss" scoped></style>
