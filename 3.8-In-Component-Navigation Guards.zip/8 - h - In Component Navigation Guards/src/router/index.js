import Vue from "vue"
import VueRouter from "vue-router"

import Home from "@/views/index"
import Details from "@/views/details"
import Gallery from "@/views/gallery"
import NotFound from "@/views/404"

Vue.use(VueRouter)

const routes = [
  { name: "index", path: "/", component: Home },
  { name: "details", path: "/details/:id", component: Details },
  { name: "gallery", path: "/gallery", component: Gallery },
  { path: "*", component: NotFound }
]

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
  console.log("beforeEach", to, from)

  next()
})

router.afterEach((to, from) => {
  console.log("afterEach", to, from)
})

export default router
