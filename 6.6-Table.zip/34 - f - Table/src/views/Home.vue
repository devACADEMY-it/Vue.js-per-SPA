<template>
  <div>
    <h1 class="title">Hello World</h1>
    <p class="subtitle">
      My first website with
      <strong>Bulma</strong>!
    </p>

    <form>
      <BField label="Email">
        <BInput type="email" v-model="email" maxlength="30"></BInput>
      </BField>

      <BField label="Password">
        <BInput
          type="password"
          v-model="password"
          password-reveal
          required
        ></BInput>
      </BField>

      <BField>
        <BButton type="is-primary" native-type="submit">Login</BButton>
      </BField>
    </form>

    <BTable :data="data" paginated :current-page.sync="page" :per-page="2">
      <template v-slot="{ row }">
        <BTableColumn field="id" label="ID" sortable>{{ row.id }}</BTableColumn>
        <BTableColumn field="email" label="Email" sortable>{{
          row.email
        }}</BTableColumn>
        <BTableColumn field="password" label="Password" sortable>{{
          row.password
        }}</BTableColumn>
      </template>
    </BTable>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoading: false,
      email: "",
      password: "",
      hasError: false,
      columns: [
        { field: "id", label: "ID" },
        { field: "email", label: "Email" },
        { field: "password", label: "Password" }
      ],
      data: [
        { id: 1, email: "prova1@gmail.com", password: "123" },
        { id: 2, email: "prova2@gmail.com", password: "123" },
        { id: 3, email: "prova3@gmail.com", password: "123" },
        { id: 4, email: "prova4@gmail.com", password: "123" },
        { id: 5, email: "prova5@gmail.com", password: "123" }
      ],
      page: 1
    }
  },
  methods: {
    checkEmail() {
      this.hasError = !this.email.includes("@")
    }
  }
}
</script>
