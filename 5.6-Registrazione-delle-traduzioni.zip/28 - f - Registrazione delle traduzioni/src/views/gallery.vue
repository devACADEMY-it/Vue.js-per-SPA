<template>
  <Api
    url="https://www.reddit.com/r/aww.json"
    v-slot="{ response, error, isLoading }"
  >
    <p v-if="isLoading">loading...</p>
    <p v-else-if="error">error!</p>
    <div v-else class="gallery">
      <figure
        class="image is-128x128"
        v-for="post of response.data.data.children"
        :key="post.data.id"
      >
        <img :src="post.data.thumbnail" />
      </figure>
    </div>
  </Api>
</template>

<script>
import Api from "@/components/Api"

export default {
  components: {
    Api
  }
}
</script>

<style lang="scss" scoped>
.gallery {
  display: flex;
  flex-wrap: wrap;
  margin: -0.25rem;

  > figure {
    padding: 0.25rem;
  }
}
</style>
