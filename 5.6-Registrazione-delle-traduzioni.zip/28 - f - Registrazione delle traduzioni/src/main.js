import Vue from "vue"
import App from "./App.vue"
import router from "./router"
import store from "./store"
import Buefy from "buefy"

import WidgetTotalHoursSTR from "@/components/WidgetTotalHours.str"
import WidgetTotalHoursXTM from "@/components/WidgetTotalHours.xtm"
import WidgetTotalHoursITM from "@/components/WidgetTotalHours.itm"
import WidgetTotalHoursJSX from "@/components/WidgetTotalHours.jsx"
import WidgetTotalHoursRDR from "@/components/WidgetTotalHours.rdr"

import "./assets/scss/app.scss"
import i18n from "./i18n"

Vue.use(Buefy)

Vue.config.productionTip = false

Vue.component("WidgetTotalHoursSTR", WidgetTotalHoursSTR)
Vue.component("WidgetTotalHoursXTM", WidgetTotalHoursXTM)
Vue.component("WidgetTotalHoursITM", WidgetTotalHoursITM)
Vue.component("WidgetTotalHoursJSX", WidgetTotalHoursJSX)
Vue.component("WidgetTotalHoursRDR", WidgetTotalHoursRDR)

new Vue({
  router,
  store,
  i18n,
  render: (h) => h(App)
}).$mount("#app")
