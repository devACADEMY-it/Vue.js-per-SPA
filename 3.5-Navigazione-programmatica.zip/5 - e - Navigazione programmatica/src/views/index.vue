<template>
  <p>index</p>
</template>

<script>
export default {}
</script>

<style lang="scss" scoped></style>
