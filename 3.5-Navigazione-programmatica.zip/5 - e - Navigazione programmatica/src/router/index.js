import Vue from "vue"
import VueRouter from "vue-router"

import Home from "@/views/index"
import Details from "@/views/details"
import Gallery from "@/views/gallery"
import NotFound from "@/views/404"

Vue.use(VueRouter)

const routes = [
  { path: "/", component: Home },
  { path: "/details/:id", component: Details },
  { path: "/gallery", component: Gallery },
  { path: "*", component: NotFound }
]

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
})

export default router
