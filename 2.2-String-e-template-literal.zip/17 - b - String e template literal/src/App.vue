<template>
  <div id="app">
    <Navbar />

    <section class="section">
      <div class="container">
        <div class="columns">
          <div class="column is-3 sidebar">
            <WidgetClickCounter />
            <WidgetTotalHoursSFC />
            <WidgetTotalHoursSTR />
          </div>
          <div class="column is-9 main">
            <router-view />
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
import Navbar from "@/components/Navbar"
import WidgetClickCounter from "@/components/WidgetClickCounter"
import WidgetTotalHoursSFC from "@/components/WidgetTotalHours.sfc"

export default {
  name: "App",

  components: {
    Navbar,
    WidgetClickCounter,
    WidgetTotalHoursSFC
  },
  methods: {
    click() {
      this.$router.push({ name: "details", params: { id: 123 } })
    }
  }
}
</script>

<style lang="scss" scoped>
.sidebar > .card:not(:last-child) {
  margin-bottom: 1rem;
}
</style>
