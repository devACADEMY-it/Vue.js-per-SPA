import Vue from "vue";
import Router from "vue-router";

// import Index from "@/views/index";
// import Details from "@/views/details";
// import Gallery from "@/views/gallery";
// import NotFound from "@/views/404";

Vue.use(Router);

const router = new Router({
  mode: "history",
  base: process.env.BASE_URL,
  routes: [
    {
      name: "index",
      path: "/",
      component: () => import(/* webpackChunkName: "index" */ "@/views/index"),
      beforeEnter: (to, from, next) => {
        console.log("beforeEnter", to, from);
        next();
      }
    },
    {
      name: "details",
      path: "/details/:id",
      component: () =>
        import(/* webpackChunkName: "details" */ "@/views/details")
    },
    {
      name: "gallery",
      path: "/gallery",
      component: () =>
        import(/* webpackChunkName: "gallery" */ "@/views/gallery")
    },
    {
      path: "*",
      component: () => import(/* webpackChunkName: "404" */ "@/views/404")
    }
  ]
});

router.beforeEach((to, from, next) => {
  console.log("beforeEach", to, from);
  next();
});

router.afterEach((to, from) => {
  console.log("afterEach", to, from);
});

export default router;
