export default {
  namespaced: true,

  state: {
    count: 0
  },
  mutations: {
    // eslint-disable-next-line no-unused-vars
    ADD(state, payload) {
      state.count++;
    }
  }
};
