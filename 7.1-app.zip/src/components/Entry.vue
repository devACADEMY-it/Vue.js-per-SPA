<template>
  <a class="box" @click="$emit('click')">
    <article class="media">
      <div class="media-left">
        <figure class="image is-64x64">
          <img
            src="https://s3.amazonaws.com/uifaces/faces/twitter/gofrasdesign/128.jpg"
            alt="Image"
          />
        </figure>
      </div>
      <div class="media-content">
        <div class="content">
          <p>
            <small>#{{ id }}</small> - <strong>Mario Rossi</strong> -
            <small>{{ humanDate }}</small>
            <br />
            {{ comment }}
          </p>
        </div>
        <small>Hours: {{ hours }}</small>
      </div>
      <div class="media-right">
        <button class="delete is-small" @click.stop="remove"></button>
      </div>
    </article>
  </a>
</template>

<script>
export default {
  name: "Entry",
  props: {
    id: { type: Number, required: true },
    date: { type: String, required: true },
    comment: { type: String, required: true },
    hours: { type: Number, required: true }
  },
  methods: {
    remove() {
      this.$emit("remove");
    }
  },
  computed: {
    humanDate() {
      return this.$d(new Date(this.date), "short");
    }
  }
};
</script>

<style lang="scss" scoped></style>
