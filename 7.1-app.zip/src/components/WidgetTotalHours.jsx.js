export default {
  name: "WidgetTotalHoursJSX",
  render() {
    return (
      <div class="card">
        <header class="card-header">
          <p class="card-header-title">Total Hours JSX</p>
        </header>
        <div class="card-content">
          <div class="content">{this.hours}</div>
        </div>
      </div>
    );
  },
  computed: {
    hours() {
      return this.$store.getters.totalHours;
    }
  }
};
