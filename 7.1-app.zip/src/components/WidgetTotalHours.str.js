export default {
  name: "WidgetTotalHoursSTR",
  template: `
    <div class="card">
      <header class="card-header">
        <p class="card-header-title">
          Total Hours STR
        </p>
      </header>
      <div class="card-content">
        <div class="content">
          {{ hours }}
        </div>
      </div>
    </div>
  `,
  computed: {
    hours() {
      return this.$store.getters.totalHours;
    }
  }
};
