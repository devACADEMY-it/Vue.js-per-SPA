export default {
  name: "WidgetTotalHoursITM",
  computed: {
    hours() {
      return this.$store.getters.totalHours;
    }
  }
};
