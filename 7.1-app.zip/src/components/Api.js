import http from "axios";

export default {
  render() {
    return this.$scopedSlots.default({
      response: this.response,
      error: this.error,
      isLoading: this.isLoading
    });
  },
  props: {
    url: { type: String, required: true }
  },
  data() {
    return {
      response: null,
      error: null,
      isLoading: false
    };
  },
  async created() {
    this.isLoading = true;

    try {
      this.response = await http.get(this.url);
    } catch (error) {
      this.error = error;
    }

    this.isLoading = false;
  }
};
