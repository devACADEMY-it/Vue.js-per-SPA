<template>
  <div class="card">
    <header class="card-header">
      <p class="card-header-title">
        Total Hours SFC
      </p>
    </header>
    <div class="card-content">
      <div class="content">
        {{ hours }}
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WidgetTotalHoursSFC",
  computed: {
    hours() {
      return this.$store.getters.totalHours;
    }
  }
};
</script>

<style lang="scss" scoped></style>
