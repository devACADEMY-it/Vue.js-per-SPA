<template>
  <p>404</p>
</template>

<script>
export default {};
</script>

<style></style>
