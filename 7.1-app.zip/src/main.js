import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import i18n from "./i18n";

import WidgetTotalHoursSTR from "@/components/WidgetTotalHours.str";
import WidgetTotalHoursXTM from "@/components/WidgetTotalHours.xtm";
import WidgetTotalHoursITM from "@/components/WidgetTotalHours.itm";
import WidgetTotalHoursJSX from "@/components/WidgetTotalHours.jsx";
import WidgetTotalHoursRDR from "@/components/WidgetTotalHours.rdr";

Vue.config.productionTip = false;

Vue.component("WidgetTotalHoursSTR", WidgetTotalHoursSTR);
Vue.component("WidgetTotalHoursXTM", WidgetTotalHoursXTM);
Vue.component("WidgetTotalHoursITM", WidgetTotalHoursITM);
Vue.component("WidgetTotalHoursJSX", WidgetTotalHoursJSX);
Vue.component("WidgetTotalHoursRDR", WidgetTotalHoursRDR);

new Vue({
  router,
  store,
  i18n,
  render: h => h(App)
}).$mount("#app");
