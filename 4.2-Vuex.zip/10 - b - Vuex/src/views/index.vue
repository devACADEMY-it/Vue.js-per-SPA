<template>
  <p>index</p>
</template>

<script>
export default {
  beforeRouteEnter(to, from, next) {
    console.log("beforeRouteEnter", to, from)

    next()
  },
  beforeRouteUpdate(to, from, next) {
    console.log("beforeRouteUpdate", to, from)

    next()
  },
  beforeRouteLeave(to, from, next) {
    console.log("beforeRouteLeave", to, from)

    next()
  }
}
</script>

<style lang="scss" scoped></style>
