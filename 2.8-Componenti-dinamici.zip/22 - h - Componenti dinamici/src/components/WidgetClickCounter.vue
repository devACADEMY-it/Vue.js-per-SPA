<template>
  <div class="card" @click="count++">
    <header class="card-header">
      <p class="card-header-title">Click Counter</p>
    </header>
    <div class="card-content">
      <div class="content">{{ count }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WidgetClickCounter",
  computed: {
    count: {
      get() {
        return this.$store.state.clicks.count
      },
      // eslint-disable-next-line no-unused-vars
      set(value) {
        this.$store.commit("clicks/ADD")
      }
    }
  }
}
</script>

<style lang="scss" scoped></style>
